<?php
if(!isset($_SESSION)) {
	session_start();
	if(isset($_SESSION["userName"])) header("Location: panel.php");
}

include("conexiones/conexionLocalhost.php");
include("rar/codigoComun.php");

// Determinar si el formulario ha sido enviado
if(isset($_POST["sent"])) {
	// Validamos los campos vacios
	foreach ($_POST as $gue => $rra) {
		if($rra == "") $error[] = "El campo $gue es obligatorio";
	}

	// Si no hay errores, definimos el query a ejecutar
	if(!isset($error)) {
		
		$queryLoginUser = sprintf("SELECT id, username, email, rango FROM users WHERE username = '%s' AND password = '%s'",
			mysql_real_escape_string($_POST["username"]),
			mysql_real_escape_string($_POST["password"])
		);

		// Ejecutamos el query
		$resQueryLoginUser = mysql_query($queryLoginUser, $db) or die("No se pudo ejecutar el query para login de usuario");

		// Contamos los resultados, si no hay, definimos un error
		if(mysql_num_rows($resQueryLoginUser)) {
			$userData = mysql_fetch_assoc($resQueryLoginUser);
			$_SESSION["userId"] = $userData["id"];
			$_SESSION["userName"] = $userData["username"];
			$_SESSION["userEmail"] = $userData["email"];
			$_SESSION["userRank"] = $userData["rango"];
			header("Location: panel.php");
		}
		else {
			$error[] = "Login incorrecto... Verifica tus datos.";
		}

	}
 
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    

    <title>Ingreso de Arabasta</title>
    <link rel="shortcut icon" type="image/png" href="images/logo.png"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
  

</head>

<body>

<div class="cuerpo">
<div class="header">

<?php include("rar/cabeza.php"); ?>


</div>
</div>
<div class="be">

<p style="font-family: Federant; font-size: 28px; text-align: center;"> 
<strong>Por favor ingresar sus datos</strong></p>

  <?php
	if(isset($error)) printMsg($error, "error ");
	if(isset($_GET["invalidAccess"])) printMsg("We're sorry but the resource that you are trying to access is forbidden... please log in first", "warning");
	if(isset($_GET["loggedOut"])) printMsg("You've been logged out succesfully... please come back anytime :)", "exito");
  ?>

<form action="login.php" method="post">
		<table>
			<tr>
				<td><label for="username">Nombre de usuario:</label></td>
				<td><input name="username" type="text" /></td>
			</tr>
			<tr>
				<td><label for="password">Password:</label></td>
				<td><input name="password" type="password" /></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input name="sent" type="submit" value="Login" /></td>
			</tr>
		</table>
	</form>

  
</div>



<?php include("rar/footer.php");?>
</div>
<?php include("sidebars/sidebar1.php");?>


</body>
</html>