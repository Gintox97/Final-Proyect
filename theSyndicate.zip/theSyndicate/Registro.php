<?php
if(!isset($_SESSION)){
	session_start();
	if(!isset($_SESSION["userEmail"]) OR $_SESSION['userRole'] != "admin") 
	header("Location: login.php?accesoInvalid=true");
}

include("conexiones/conexionLocalhost.php");
include("rar/codigoComun.php");

if(isset($_POST['sent'])){
	foreach($_POST as $gue => $rra){
		if($gue != "telefono"){
			if($rra == ""){ $error[] = "La caja $gue debe contener un valor";}
		}
	}

	if($_POST["username"] != $_POST["password"]){
		$error[] = "No se permite poner tu nombre de usuario como contraseña";
	}


if($_POST["password"] != $_POST["password2"]){
	$error[] = "Las contraseñas no coinciden";
}
$queryCheckEmail = sprintf("SELECT id FROM users WHERE email AND = '%s'",
mysql_real_escape_string(trim($_POST["email"]))
);

$resQueryCheckEmail = mysql_query($queryCheckEmail, $db) or die("El query para verificar el email falló");


if(mysql_num_rows($resQueryCheckEmail)) {
	$error[] = "El nombre de usuario proporcionado ya está siendo utilizado";
}



if(!isset($error)) {
	// Definimos la consulta que se va a ejecutar para guardar los datos del usuario
	$queryUserRegister = sprintf("INSERT INTO users (username, email, password, rango, genero, rol, telefono) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s')",
		mysql_real_escape_string(trim($_POST["username"])),
		mysql_real_escape_string(trim($_POST["email"])),
		mysql_real_escape_string(trim($_POST["password"])),
		mysql_real_escape_string(trim($_POST["rango"])),
		mysql_real_escape_string(trim($_POST["genero"])),
		mysql_real_escape_string(trim($_POST["rol"])),
		mysql_real_escape_string(trim($_POST["telefono"]))
	);

	// Ejecutamos el query
	$resQueryUserRegister = mysql_query($queryUserRegister, $db) or die("No se pudo guardar el usuario en la BD... Revisa tu código plomo.");

	// Si los datos fueron guardados con exito hacemos una redirección
	if($resQueryUserRegister) {
		header("Location: panel.php?registroUsuario=true");
	} 

}

}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    

    <title>Registro a Arabasta</title>
    <link rel="shortcut icon" type="image/png" href="images/logo.png"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
  

</head>

<body>

<div class="cuerpo">
<div class="header">

<?php include("rar/cabeza.php"); ?>


</div>
</div>
<div class="be">

<p style="font-family: Federant; font-size: 28px; text-align: center;"> 
<strong>Por favor de no dejar espacios vacios al momento de ingresar sus datos</strong></p>

<form action="Registro.php" method="post">
<table>
		<tr>
		  <td><label for="username"><strong>Nombre:</strong></label></td>
		  <td><input type="text" name="username" placeholder="Aqui pones el nombre de usuario."
           value="<?php if(isset($_POST['username'])) echo $_POST['username']; ?>"></td>
		</tr>
        <tr>
		  <td><label for="email"><strong>Email:</strong></label></td>
		  <td><input type="text" name="email" placeholder="Ingresa tu Correo Electronico."
           value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>"></td>
		</tr>
        <tr>
		  <td><label for="password"><strong>Password:</strong></label></td>
		  <td><input type="password" name="password"></td>
		</tr>
		<tr>
		  <td><label for="password2"><strong>Password 2:</strong></label></td>
		  <td><input type="password" name="password2"></td>
		</tr>
        <tr>
		  <td><label for="rango"><strong>Rango:</strong></label></td>
		  <td>
			 <select name="rango">
				<option value="admin" <?php if(isset($_POST['rango']) AND $_POST['rango'] == "admin") echo 'selected="selected"'; ?>>Usuario</option>
				<option value="usuario" <?php if(isset($_POST['rango']) AND $_POST['rango'] == "usuario") echo 'selected="selected"'; ?>>Administrador</option>
				<option value="gerente" <?php if(isset($_POST['rango']) AND $_POST['rango'] == "gerente") echo 'selected="selected"'; ?>>Gerente</option>
			 </select>
		  </td>
		</tr>
        <tr>
		  <td><label for="genero"><strong>Genero:</strong></label></td>
		  <td>
			 <select name="genero">
				<option value="hombre" <?php if(isset($_POST['genero']) AND $_POST['genero'] == "hombre") echo 'selected="selected"'; ?>>Hombre</option>
				<option value="mujer" <?php if(isset($_POST['genero']) AND $_POST['genero'] == "mujer") echo 'selected="selected"'; ?>>Mujer</option>
			 </select>
		  </td>
		</tr>
        <tr>
		  <td><label for="rol"><strong>Rol:</strong></label></td>
		  <td>
			 <select name="rol">
				<option value="luchador" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "luchador") echo 'selected="selected"'; ?>>Luchador</option>
				<option value="mago" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "mago") echo 'selected="selected"'; ?>>Mago</option>
                <option value="asesino" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "asesino") echo 'selected="selected"'; ?>>Asesino</option>
                <option value="tanque" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "tanque") echo 'selected="selected"'; ?>>Tanque</option>
                <option value="soporte" <?php if(isset($_POST['rol']) AND $_POST['rol'] == "soporte") echo 'selected="selected"'; ?>>Soporte</option>
			 </select>
		  </td>
		</tr>
		<tr>
		  <td><label for="telefono"><strong>Telefono:</strong></label></td>
		  <td><input type="text"  name="telefono" placeholder="Ingresa tu Telefono"
           value="<?php if(isset($_POST['telefono'])) echo $_POST['telefono']; ?>"></td>
		</tr>
        <tr>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
		</tr>
		<tr>
		  <td><input type="submit" value="Guardar usuario" name="sent" /></td>
		  <td>&nbsp;</td>
		</tr>


</table>
</form>

<?php include("rar/footer.php");?>
</div>
<?php include("sidebars/sidebar1.php");?>


</body>
</html>