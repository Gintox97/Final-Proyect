<?php
if(!isset($_SESSION)) {
	session_start();
	if(!isset($_SESSION["userEmail"]) OR $_SESSION['userRole'] != "admin") header("Location: login.php?invalidAccess=true");
}

include("conexiones/conexionLocalhost.php");
include("includes/codigoComun.php");

// Obtenemos todos los usuarios de la base de datos
$queryGetUsers = "SELECT id, username, email FROM users";

// Ejecutamos el query
$resQueryGetUser = mysql_query($queryGetUsers, $db) or die("No se pudo ejecutar el query para obtener todos los usuarios");

// Extraemos (fetch) del recordset los datos del primer usuario
$userDetail = mysql_fetch_assoc($resQueryGetUser);

// Contamos el total de usuarios encontrados
$totalUsers = mysql_num_rows($resQueryGetUser);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    

    <title>Edicion de Perfiles</title>
    <link rel="shortcut icon" type="image/png" href="images/logo.png"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
  

</head>

<body>

<div class="cuerpo">
<div class="header">

<?php include("rar/cabeza.php"); ?>


</div>
</div>
<div class="be">




  <h2>Manejo de usuarios</h2>
  <p>Use las opciones para manejo de usuarios</p>
  <p>There are <?php echo $totalUsers;?> Usuarios registrados.</p>

  <?php
	if(isset($_GET["registroUsuario"])) printMsg("El usuario ha sido registrado con éxito", "exito");
  ?>

  <ul class="listadoUsuarios">
    <?php
    do { ?>
    <li>
      <p class="nombreUsuario"><?php echo $userDetail['username']; ?> - <?php echo $userDetail['email']; ?></p>
      <p class="accionesUsuario">
        <a href="user_edit_admin.php?userId=<?php echo $userDetail['id']; ?>">Editar</a> | <a href="user_delete.php?userId=<?php echo $userDetail['id']; ?>">Eliminar</a>
      </p>
    </li>
    <?php } while($userDetail = mysql_fetch_assoc($resQueryGetUser)); ?>
  </ul>
  
</div>

<?php include("rar/footer.php");?>
</div>
<?php include("sidebars/sidebar1.php");?>


</body>
</html>