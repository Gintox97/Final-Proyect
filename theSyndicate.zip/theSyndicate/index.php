<?php
include("conexiones/conexionLocalhost.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    

    <title>Reings of Arabasta</title>
    <link rel="shortcut icon" type="image/png" href="images/logo.png"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
  

</head>

<body>
<div class="cuerpo">
<div class="header">
<?php include("rar/cabeza.php"); ?>


</div>
</div>
<div class="be">
<h3 class="r-mist">
WELCOME!!
</h3>
<h4 class="r-mist" style="font-size: 40px;">
<strong>"Arabasta Aguarda a sus Protectores"</strong></h4>


<p class="r-mist" style="font-size:20px; text-align: left;">
Arabasta, es una región donde habitan diversas especies con distintas habilidades que van desde un simple humano pero 
con gran fuerza y carisma, hasta gente que domina las artes magicas, pero no todo es luz en esta región debido a que un 
mal acecha poniendo en riesgo la vida de miles de personas y es tu deber proteger a la region y a tu reino.
</p>
<img src="https://d1u5p3l4wpay3k.cloudfront.net/lifeisfeudal_gamepedia/4/4a/MMO_map_.jpg?version=b6766840bc99f641513e4110f7a68fd4"
 alt="Mapa de arabasta"
style="display: block;
    margin-left: auto;
    margin-right: auto;">
<h4 class="r-mist" style="font-size: 40px;">
<strong>Objetivo</strong></h4>

<p class="r-mist" style="font-size:20px; text-align: left;">
Sube nivel y experiencia completando las diferentes misiones que se daran cada semana.
Mediante los cuales se ganarán recompensas que van desde oro hasta nuevos items para tu inventario.

<img src="http://2.bp.blogspot.com/-hc7LVLUhG6E/U2p4B6vElkI/AAAAAAAAUSk/cC9rzt8s1rA/s1600/eureka_ingot_and_coin.gif"
alt="Oro" style="width: 200px; margin-left: 100px;" >
<img src="https://png.pngtree.com/element_origin_min_pic/16/11/14/91b1274aedbe65b172f9c4163ff36b2f.jpg" alt="Items"
style=" margin-left: 100px;
    width: 250px;">
</p>
<?php include("rar/footer.php");?>
</div>
<?php include("sidebars/sidebar.php");?>


</body>
</html>