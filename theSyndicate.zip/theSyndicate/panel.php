<?php
if(!isset($_SESSION)) {
	session_start();
	if(!isset($_SESSION["userEmail"])) header("Location: login.php?invalidAccess=true");
}

include("conexiones/conexionLocalhost.php");
include("rar/codigoComun.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    

    <title>Perfil-Arabasta</title>
    <link rel="shortcut icon" type="image/png" href="images/logo.png"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
  

</head>

<body>

<div class="cuerpo">
<div class="header">

<?php include("rar/cabeza.php"); ?>


</div>
</div>
<div class="be">

<h2>Panel de Control</h2>

 <?php
	if(isset($_GET["registroUsuario"])) printMsg("El usuario ha sido registrado con éxito", "exito");
	if(isset($_GET["updateUsuario"])) printMsg("El usuario ha sido actualizado con éxito", "exito");
  ?>

<p>Administra tu perfil</p>
<div class="h-buttons">
<ul>
  <li><a href="user_edit.php">Editar Perfil</a></li>
  <li><a href="">Manejar propiedades</a></li>
  <?php
  if($_SESSION['userRole'] == "admin"){ ?>
    <li><a href="">Manejar usuarios</a></li>
    <li><a href="">Manejar gerentes</a></li>
  <?php } ?>
  <li><a href="">Trash</a></li>
</ul>



<?php include("rar/footer.php");?>
</div>
</div>
<?php include("sidebars/sidebar1.php");?>


</body>
</html>