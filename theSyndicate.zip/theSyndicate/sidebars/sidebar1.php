<div id="sidebar">
<div class="sb" id="rar">

<h4 style="font-size: 20px"> Preguntas Generales </h4>
<a href="#"> ¿Es obligatorio poner el correo?</a>
<a href="#"> ¿Que requisitos necesito?</a>
<a href="#"> ¿como puedo ser administrador?</a>

<br>

<div class="txt_navbar" id="logoff">
    <?php echo (isset($_SESSION["userEmail"])) ? "Greetings <strong>".$_SESSION["userName"]."</strong>" : '<a href="login.php">Login</a>'; ?>
    <br />
      <a href="?logout=true">Cerrar Sesion</a></div>
</div>

</div>
</div>