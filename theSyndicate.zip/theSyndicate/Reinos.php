<?php
include("conexiones/conexionLocalhost.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    

    <title>Reings of Arabasta</title>
    <link rel="shortcut icon" type="image/png" href="images/logo.png"/>
    <link href="css/style.css" type="text/css" rel="stylesheet"/>
  

</head>

<body>
<div class="cuerpo">
<div class="header">
<?php include("rar/cabeza.php"); ?>


</div>
</div>
<div class="be">
<h4 class="r-mist" style="font-size: 40px;">
<strong>Reinos Pertenecientes a Arabasta</strong></h4>
<br>
<p style="font-family: Federant; font-size:20px; text-align: center;">

<img src="https://d2v9y0dukr6mq2.cloudfront.net/video/thumbnail/yRF5c-O/videoblocks-haunted-castle-fort-mansion-house-palace-on-a-spooky-hill-hilltop-horror-full-moon-cloudy-sky-lightening-storm-house-on-haunted-mountain_ss_auuxlb_thumbnail-full02.png"
 alt="Castillo de Inframundo"
align: "left" style="width: 400px;">
Inframundo un reino dictador que esta en las zonas oscuras al sur de la Región de Arabasta donde la gente vive de ganancias 
proporcionadas por altos indices de saqueos a pequeñas ciudades, es de los reinos mas codiciosos en toda la región 
pero con una alta reputación de otros ámbitos, principalmente sus asesinos y magos, los cuales en su mayoria son grandes montruos.</p>

<br>
<p style="font-family: Federant; font-size:20px;">
<img src="https://i.pinimg.com/originals/d8/a6/88/d8a6883e994f86d71cf049a81ffff418.jpg"
 alt="Castillo de Cimmeria"
align: "left" style="width: 400px;">
Cimmeria, Reino al lado norte de Arabasta, 
</p>

<br>
<p style="font-family: Federant; font-size:20px;">
<img src="http://www.g4g.it/g4g2/wp-content/uploads/2009/11/Castle_of_Heroes_01.jpg"
 alt="Castillo de Tierra Media"
align: "left" style="width: 400px;">
</p>

<br>
<p style="font-family: Federant; font-size:20px;">
<img src="https://vignette.wikia.nocookie.net/saintseiya/images/4/49/Hades_Castle_pq.jpg/revision/latest?cb=20120603162123&path-prefix=es"
 alt="Castillo de Azhrat"
align: "left" style="width: 400px;">
</p>




<?php include("rar/footer.php");?>
</div>
<?php include("sidebars/sidebar.php");?>


</body>
</html>